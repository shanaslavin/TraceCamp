from django.apps import AppConfig


class Kick2Config(AppConfig):
    name = 'kick2'
