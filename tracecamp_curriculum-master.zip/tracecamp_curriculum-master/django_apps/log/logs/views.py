from django.shortcuts import render

# Create your views here.

# View to view a list of the logs

# View for 
