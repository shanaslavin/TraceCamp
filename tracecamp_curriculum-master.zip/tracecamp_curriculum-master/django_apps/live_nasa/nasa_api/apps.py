from django.apps import AppConfig


class NasaApiConfig(AppConfig):
    name = 'nasa_api'
