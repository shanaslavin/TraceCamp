from django.apps import AppConfig


class KickApiConfig(AppConfig):
    name = 'kick_api'
