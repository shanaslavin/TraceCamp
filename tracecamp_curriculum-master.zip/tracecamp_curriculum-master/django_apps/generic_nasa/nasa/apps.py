from django.apps import AppConfig


class NasaConfig(AppConfig):
    name = 'nasa'
